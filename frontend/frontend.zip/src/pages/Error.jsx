
const Error = () => {
  return (
    <div>
      Error
      Error 404
      page not found 404
    </div>
  )
}

export default Error
